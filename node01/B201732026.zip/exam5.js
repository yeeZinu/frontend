function add(a, ...values) {
    return a.push(...values);
    }
    let a = [0, 1]
    add(a, 2, 3, 4, 5)
    console.log(a)
    