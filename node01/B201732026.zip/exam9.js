let persons = [
    { name: "홍길동", age: 16 },
    ];

    persons[1] = persons[0];
    persons[2] = persons[1];
    console.log(persons);