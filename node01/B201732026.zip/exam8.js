function countProperties(obj) {
    for(){

    }
}

let person = { name: '홍길동', age: 16, height: 180 }
let count = countProperties(person)
console.log(count)