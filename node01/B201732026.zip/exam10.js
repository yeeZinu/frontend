let person = [];
let a = {name: "홍길동", age: 16 };
for(let i =1; i < 11; i++){
    person.push(a);
    console.log(person.push(i));
}

console.log(person);